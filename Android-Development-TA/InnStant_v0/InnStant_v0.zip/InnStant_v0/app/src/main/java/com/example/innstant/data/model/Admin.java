package com.example.innstant.data.model;

public class Admin {
}
