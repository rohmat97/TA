package com.example.innstant.data;

public class PreferenceHelper {
    private static final String BASE_URL = "https://127.0.0.1:9029";

    public static String getBaseUrl() {
        return BASE_URL;
    }
}
