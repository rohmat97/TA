package com.example.innstant.data.api.Interface;

public class InnstantDataSource {
}
