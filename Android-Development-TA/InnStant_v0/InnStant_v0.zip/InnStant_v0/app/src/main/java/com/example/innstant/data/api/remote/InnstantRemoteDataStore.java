package com.example.innstant.data.api.remote;

public class InnstantRemoteDataStore {
}
