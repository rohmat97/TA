package com.example.innstant.data.api;

public interface ApiInterface {
}
