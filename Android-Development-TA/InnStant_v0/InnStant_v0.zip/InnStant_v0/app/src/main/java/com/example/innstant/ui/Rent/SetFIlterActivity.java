package com.example.innstant.ui.Rent;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.innstant.R;

public class SetFIlterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_filter);
        setTitle("Set FIlter");
    }
}
